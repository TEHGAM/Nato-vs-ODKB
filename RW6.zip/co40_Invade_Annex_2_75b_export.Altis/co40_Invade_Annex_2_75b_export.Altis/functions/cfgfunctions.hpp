class QS
{
	tag = "QS";
	class functions
	{
		file = "functions";
		class cleanGroups {};
		class deleteOldAOUnits {};
		class deleteOldUnitsAndVehicles {};
		class deleteUnits {};
		class garrisonBuildings {};
		class minefield {};
		class rewardPlusHint {};
		class rewardPlusHintJet {};
		class serverMapTP {};
		class setSkill1 {};
		class setSkill2 {};
		class setSkill3 {};
		class setSkill4 {};
		class spawnUnits {};
	};
};